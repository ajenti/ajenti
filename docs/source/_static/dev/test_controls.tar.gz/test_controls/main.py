from ajenti.api import plugin
from ajenti.plugins.main.api import SectionPlugin
from ajenti.ui import on, p, UIElement


@plugin
class Test (SectionPlugin):
    def init(self):
        self.title = 'Controls'
        self.icon = 'smile'
        self.category = 'Demo'
        self.append(self.ui.inflate('test_controls:main'))

    @on('check', 'click')
    def on_show(self):
        self.context.notify('info', 'Value is %i' % self.find('slider').value)


@p('value', type=int, default=0)
@plugin
class Slider (UIElement):
    typeid = 'slider'
